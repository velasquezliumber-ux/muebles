// Función dinámica para filtrar tarjetas por disponibilidad
function filtrarMuebles(estado) {
    // Seleccionar todas las tarjetas de muebles
    const tarjetas = document.querySelectorAll('.tarjeta-mueble');
    // Seleccionar todos los botones de filtro
    const botones = document.querySelectorAll('.btn-filtro');

    // Cambiar la clase activa en los botones de filtro
    botones.forEach(boton => {
        boton.classList.remove('activo');
        if (
            boton.textContent.toLowerCase().includes(estado) || 
            (estado === 'todos' && boton.textContent.includes('Todo')) ||
            (estado === 'agotado' && boton.textContent.toLowerCase().includes('pedido'))
        ) {
            boton.classList.add('activo');
        }
    });

    // Mostrar u ocultar las tarjetas según el filtro seleccionado
    tarjetas.forEach(tarjeta => {
        const estadoMueble = tarjeta.getAttribute('data-estado');

        if (estado === 'todos' || estadoMueble === estado) {
            tarjeta.style.display = 'block';
            // Efecto sutil de aparición gradual
            tarjeta.style.opacity = '0';
            setTimeout(() => {
                tarjeta.style.opacity = '1';
                tarjeta.style.transition = 'opacity 0.4s ease';
            }, 10);
        } else {
            tarjeta.style.display = 'none';
        }
    });
}
